# Changelog

## v0.3.0 (2026-04-02)

### Added
- **`iil_testkit.contract` module** — Platform-weiter Contract-Verifier (ADR-155)
  - `ContractVerifier(cls)` — Klassen-API Contracts (Package-APIs, Service-Layer)
  - `CallableContractVerifier(func)` — Freie Funktionen
  - `TaskContractVerifier(task)` — Celery Task Signaturen (korrekte Introspection)
  - `ResponseShapeVerifier(shape)` — REST API Response-Shapes
  - `BaseContractVerifier` — Gemeinsame ABC-Basis
- Factory Methods: `ContractVerifier.for_callable()`, `ContractVerifier.for_task()`
- `assert_init_params(exhaustive=True)` — bidirektionale Parameterprüfung
- `assert_raises()` — Exception-Docstring-Contracts (assert statt warnings.warn)
- `assert_return_keys()` — Return-Shape-Contracts (assert statt warnings.warn)
- `assert_return_origin()` — Generic Return-Type Prüfung
- `assert_is_acks_late()` — Celery Platform-Standard Prüfung
- 53 neue Tests für alle Verifier-Typen

## v0.2.0 (2026-03-10)

### Added
- `drf_api_client` fixture — unauthenticated DRF `APIClient` (auto-skips if DRF not installed)
- `drf_auth_client` fixture — DRF `APIClient` authenticated as `db_user` via `force_authenticate`
- `[drf]` optional dependency group in `pyproject.toml`
- `CHANGELOG.md`

### Fixed
- **BREAKING BUG**: `plugin.py` used `pytest.fail()` in `pytest_collection_modifyitems` which
  caused `INTERNALERROR` (not a normal test failure) when naming violations were found
- Changed default `iil_naming_mode` from `"error"` to `"warn"` — naming convention is now
  advisory by default; opt-in to `"error"` mode explicitly when all tests follow `test_should_*`
- `pytest.fail()` replaced with `pytest.UsageError()` in error-mode to produce a proper
  collection error instead of INTERNALERROR

### Changed
- All Django-Hub repos should now use `iil-testkit>=0.2.0` in `requirements-test.txt`
- Repos with legacy `test_*` naming will get a warning, not a hard failure

## v0.1.0 (2026-03-06)

### Added
- Initial release
- `UserFactory`, `StaffUserFactory`, `AdminUserFactory`
- `db_user`, `staff_user`, `admin_user`, `api_client`, `auth_client`, `staff_client` fixtures
- `assert_redirects_to_login`, `assert_htmx_response`, `assert_no_n_plus_one`, `assert_form_error`
- `iil-testkit` pytest plugin enforcing `test_should_*` naming convention (ADR-057)
- `iil_testkit.contrib.tenants.TenantFactory` for multi-tenant repos
